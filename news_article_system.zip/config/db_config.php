<?php return array(
      'database_host' => 'localhost',
      'database_name' => 'news_article_system',
      'database_user' => 'root',
      'database_password' => ''
);